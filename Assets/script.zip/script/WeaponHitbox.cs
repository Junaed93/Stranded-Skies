using UnityEngine;

public class WeaponHitbox : MonoBehaviour
{
    Collider2D col;

    void Awake()
    {
        col = GetComponent<Collider2D>();
        col.enabled = false;
    }

    // Called by animation event
    public void EnableHitbox()
    {
        col.enabled = true;
    }

    // Called by animation event
    public void DisableHitbox()
    {
        col.enabled = false;
    }
}

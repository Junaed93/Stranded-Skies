using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    public Transform player;
    public float moveSpeed = 2f;
    public float detectRange = 6f;
    public float attackRange = 1.2f;
    public float attackCooldown = 1.5f;

    float timer;
    Rigidbody2D rb;
    Health health;
    EnemyAttack attack;
    Animator anim;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        health = GetComponent<Health>();
        attack = GetComponent<EnemyAttack>();
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        if (health.isDead) return;

        float dist = Vector2.Distance(transform.position, player.position);
        timer += Time.deltaTime;

        if (dist <= attackRange)
        {
            rb.linearVelocity = Vector2.zero;
            if (anim) anim.SetBool("Run", false);

            if (timer >= attackCooldown)
            {
                attack.DoAttack();
                timer = 0f;
            }
        }
        else if (dist <= detectRange)
        {
            Vector2 dir = (player.position - transform.position).normalized;
            rb.linearVelocity = new Vector2(dir.x * moveSpeed, rb.linearVelocity.y);
            if (anim) anim.SetBool("Run", true);
        }
        else
        {
            rb.linearVelocity = Vector2.zero;
            if (anim) anim.SetBool("Run", false);
        }
    }
}

using UnityEngine;

public class Health : MonoBehaviour
{
    public int maxHealth = 100;
    public int currentHealth;
    public bool isDead = false;

    Rigidbody2D rb;
    Collider2D col;

    void Awake()
    {
        currentHealth = maxHealth;
        rb = GetComponent<Rigidbody2D>();
        col = GetComponent<Collider2D>();
    }

    public void TakeDamage(int damage)
    {
        if (isDead) return;

        if (GameSession.Instance.mode == GameMode.SinglePlayer)
        {
            ApplyDamage(damage);
        }
        else
        {
            // Multiplayer: Intent only, actual damage applied via external call (NetworkApplyDamage stub)
            Debug.Log($"[Multiplayer] {gameObject.name} damage requested ({damage}) but not applied locally.");
        }
    }

    // 🌐 Entry point for multiplayer damage confirmation or singleplayer application
    public void ApplyDamage(int damage)
    {
        currentHealth -= damage;
        Debug.Log(gameObject.name + " HP: " + currentHealth);

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        isDead = true;

        // Stop physics
        if (rb)
        {
            rb.linearVelocity = Vector2.zero;
            rb.bodyType = RigidbodyType2D.Kinematic;
        }

        // Disable collisions
        if (col)
            col.enabled = false;

        // Disable all scripts except Health
        MonoBehaviour[] scripts = GetComponents<MonoBehaviour>();
        foreach (MonoBehaviour s in scripts)
        {
            if (s != this)
                s.enabled = false;
        }

        Debug.Log(gameObject.name + " died");
    }
}

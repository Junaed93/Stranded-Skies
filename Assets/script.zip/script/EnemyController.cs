using UnityEngine;

public class EnemyController : MonoBehaviour
{
    [Header("Stats")]
    public int maxHealth = 100;
    int currentHealth;

    [Header("Components")]
    public Animator animator;
    public Rigidbody2D rb;
    public Collider2D myCollider;

    void Start()
    {
        currentHealth = maxHealth;
        rb.gravityScale = 1;
        rb.freezeRotation = true;
    }

    public void TakeDamage(int damage)
    {
        if (currentHealth <= 0) return;

        currentHealth -= damage;

        // MATCHES YOUR PARAMETER: "Hit"
        animator.SetTrigger("Hit");

        if (currentHealth <= 0)
        {
            Die();
        }
    }
    void Die()
    {
        animator.SetTrigger("Death");

        // Stop falling through the floor
        if (rb != null)
        {
            rb.bodyType = RigidbodyType2D.Kinematic;
            rb.linearVelocity = Vector2.zero;
        }

        // Allow player to walk through the dead body
        if (myCollider != null)
        {
            myCollider.enabled = false;
        }

        // Disable the AI so it stops attacking
        if (GetComponent<EnemyAI>() != null)
        {
            GetComponent<EnemyAI>().enabled = false;
        }

        // Disable this script
        this.enabled = false;

        // --- IMPORTANT: I REMOVED THE DESTROY LINE HERE ---
        // The body will now stay on the ground forever.
    }
}
using UnityEngine;

public class PlayerCombat : MonoBehaviour
{
    [Header("Player Stats")]
    public int maxHealth = 100;
    int currentHealth;
    public bool isDead = false;

    [Header("Attack Settings")]
    public Transform attackPoint; // You must create an empty child object for this
    public float attackRange = 0.5f;
    public int attackDamage = 20;
    public LayerMask enemyLayers; // Set this to "Enemy" in Inspector

    [Header("Components")]
    public Animator animator;

    void Start()
    {
        currentHealth = maxHealth;
    }

    void Update()
    {
        if (isDead) return;

        // Left Click to Attack
        if (Input.GetButtonDown("Fire1"))
        {
            Attack();
        }
    }

    void Attack()
    {
        // 1. Play Attack Animation (Matches your "Attack1" parameter)
        animator.SetTrigger("Attack1");

        // 2. Detect Enemies in range of attack
        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(attackPoint.position, attackRange, enemyLayers);

        // 3. Damage them
        foreach(Collider2D enemy in hitEnemies)
        {
            // Try to find the EnemyController script on the object we hit
            EnemyController enemyScript = enemy.GetComponent<EnemyController>();
            
            if (enemyScript != null)
            {
                enemyScript.TakeDamage(attackDamage);
            }
        }
    }

    // Call this when the Enemy hits the Player
    public void TakeDamage(int damage)
    {
        if (isDead) return;

        currentHealth -= damage;

        // Play Hurt Animation (Matches your "Hurt" parameter)
        animator.SetTrigger("Hurt");

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        isDead = true;
        // Play Death Animation (Matches your "Death" trigger & "IsDead" bool)
        animator.SetTrigger("Death");
        animator.SetBool("IsDead", true);

        // Disable player movement script here if you have a separate one
        // GetComponent<PlayerMovement>().enabled = false;
    }
    
    // Visualize the attack range in the Editor to make it easier to adjust
    void OnDrawGizmosSelected()
    {
        if (attackPoint == null) return;
        Gizmos.DrawWireSphere(attackPoint.position, attackRange);
    }
}
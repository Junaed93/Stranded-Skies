using UnityEngine;

public class PlayerCombat : MonoBehaviour
{
    [Header("Player Stats")]
    public int maxHealth = 100;
    int currentHealth;
    bool isDead = false;

    [Header("Attack Settings")]
    public Transform attackPoint;
    public float attackRange = 0.5f;
    public int attackDamage = 20;
    public LayerMask enemyLayers;

    [Header("Components")]
    public Animator animator;

    void Start()
    {
        currentHealth = maxHealth;
    }

    void Update()
    {
        if (isDead) return;

        if (Input.GetButtonDown("Fire1"))
        {
            Attack();
        }
    }

    void Attack()
    {
        // MATCHES YOUR PARAMETER: "Attack1"
        animator.SetTrigger("Attack1");

        // Detect enemies
        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(attackPoint.position, attackRange, enemyLayers);

        // Damage them
        foreach (Collider2D enemy in hitEnemies)
        {
            EnemyController enemyScript = enemy.GetComponent<EnemyController>();
            if (enemyScript != null)
            {
                enemyScript.TakeDamage(attackDamage);
            }
        }
    }

    public void TakeDamage(int damage)
    {
        if (isDead) return;

        currentHealth -= damage;

        // MATCHES YOUR PARAMETER: "Hurt"
        animator.SetTrigger("Hurt");

        if (currentHealth <= 0)
        {
            Die();
        }
    }
void Die()
    {
        isDead = true;
        
        // 1. Play Death Animation
        animator.SetTrigger("Death");
        animator.SetBool("IsDead", true);

        // 2. THE MAGIC FIX: Disable ALL other scripts
        // This stops your movement, jumping, and anything else automatically.
        // It works even if you renamed your script!
        MonoBehaviour[] scripts = GetComponents<MonoBehaviour>();
        foreach(MonoBehaviour script in scripts)
        {
            // If the script is NOT this Combat script, turn it off.
            if (script != this)
            {
                script.enabled = false;
            }
        }

        // 3. FREEZE PHYSICS (Stops sliding on the ground)
        Rigidbody2D rb = GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.bodyType = RigidbodyType2D.Static; 
        }

        // 4. Disable this Combat Script so you can't attack while dead
        this.enabled = false;
    }

    void OnDrawGizmosSelected()
    {
        if (attackPoint == null) return;
        Gizmos.DrawWireSphere(attackPoint.position, attackRange);
    }
}
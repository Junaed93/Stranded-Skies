using UnityEngine;

public class PlayerCombat : MonoBehaviour, IDamageable
{
    [Header("Player Stats")]
    public int maxHealth = 100;
    private int currentHealth;
    private bool isDead = false;

    [Header("Attack Settings")]
    public Transform attackPoint;
    public float attackRange = 0.5f;
    public int attackDamage = 20;
    public LayerMask enemyLayers;

    [Header("Survival Settings")]
    public int maxRespawns = 3;
    public float minHeight = -20f; // Fall threshold
    private int currentRespawns;

    [Header("Heal/Regen Settings")]
    public float regenRate = 5f; // HP per second
    public float regenDelay = 3f; // Seconds after damage before regen starts
    private float lastDamageTime;
    private float regenAccumulator;

    [Header("Combo Settings")]
    public float comboResetTime = 0.9f;

    [Header("Audio")]
    public AudioSource audioSource;
    public AudioClip swordSwingSFX;
    public AudioClip swordHitSFX;
    public AudioClip blockSFX;

    [Header("Components")]
    public Animator animator;

    private SpriteRenderer spriteRenderer;

    private int comboIndex = 0;
    private float lastAttackTime;
    private bool isAttacking = false;

    private bool facingRight = true;

    // 🔒 Block (TRIGGER – ONE HIT)
    private bool isBlocking = false;

    private Vector3 attackPointStartLocalPos;
    private AutoCheckpoint autoCheckpoint; // [NEW]

    void Start()
    {
        currentHealth = maxHealth;
        currentRespawns = maxRespawns; // [NEW] Init lives

        spriteRenderer = GetComponentInChildren<SpriteRenderer>();
        if (!audioSource) audioSource = GetComponent<AudioSource>();

        attackPointStartLocalPos = attackPoint.localPosition;
        autoCheckpoint = GetComponent<AutoCheckpoint>(); // [NEW]

        // [NEW] Initial UI Update
        if (PlayerHealthUI.Instance != null)
            PlayerHealthUI.Instance.UpdateHealth(currentHealth, maxHealth);
    }

    void Update()
    {
        if (isDead) return;

        // [NEW] Fall Check
        if (transform.position.y < minHeight)
        {
            Die(); // Call Die directly for falls
        }

        HandleRegeneration();

        // [NEW] Manual Heal (Press H)
        if (Input.GetKeyDown(KeyCode.H))
        {
            Heal(20);
        }

        HandleFacingDirection();

        // 🛡️ BLOCK (RIGHT CLICK – HOLD)
        if (Input.GetMouseButtonDown(1))
        {
            isBlocking = true;
            animator.SetBool("IdleBlock", true); // Trigger looping block animation
            animator.SetTrigger("Block");
            PlaySound(blockSFX);
        }
        
        if (Input.GetMouseButtonUp(1))
        {
            isBlocking = false;
            animator.SetBool("IdleBlock", false);
        }

        // Prevent attacking while blocking
        bool blockHeld = Input.GetMouseButton(1);
        isBlocking = blockHeld;

        // ⚔️ ATTACK
        if (Input.GetButtonDown("Fire1") && !isAttacking && !isBlocking)
        {
            StartCombo();
        }
    }

    // ---------------- FACING ----------------

    void HandleFacingDirection()
    {
        float horizontal = Input.GetAxisRaw("Horizontal");

        if (horizontal > 0.1f && !facingRight)
            Flip();
        else if (horizontal < -0.1f && facingRight)
            Flip();
    }

    void Flip()
    {
        facingRight = !facingRight;

        if (spriteRenderer != null)
            spriteRenderer.flipX = !spriteRenderer.flipX;

        Vector3 pos = attackPointStartLocalPos;
        pos.x *= facingRight ? 1 : -1;
        attackPoint.localPosition = pos;
    }

    // ---------------- ATTACK ----------------

    void StartCombo()
    {
        comboIndex++;
        if (comboIndex > 3) comboIndex = 1;

        animator.SetTrigger("Attack" + comboIndex);
        lastAttackTime = Time.time;
        isAttacking = true;

        PlaySound(swordSwingSFX);
        
        // [FIX] Auto-trigger detection in case Animation Event is missing
        Invoke(nameof(DealDamage), 0.3f); 
        Invoke(nameof(EndAttack), 0.8f);
    }

    // 🔥 ANIMATION EVENT (HIT FRAME) - Now also called by Invoke
    public void DealDamage()
    {
        // Auto-Fix LayerMask: If it's 0 (Nothing) or 1 (Default), just hit EVERYTHING
        int mask = enemyLayers;
        if (mask <= 1) mask = ~0; 

        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(
            attackPoint.position,
            attackRange,
            mask
        );

        foreach (Collider2D enemy in hitEnemies)
        {
             // Don't hit yourself
             if (enemy.gameObject == gameObject) continue;

             // Use Central Combat System
             if (CombatSystem.Instance != null && GameModeManager.Instance.IsMultiplayer())
             {
                  CombatSystem.Instance.RequestDamage(enemy.gameObject, attackDamage);
             }
             // Fallback / Singleplayer
             else if (enemy.TryGetComponent(out IDamageable damageable))
            {
                damageable.TakeDamage(attackDamage);
                PlaySound(swordHitSFX);
                Debug.Log($"[PlayerCombat] HIT {enemy.name} for {attackDamage} damage.");
            }
        }
    }

    // 🔚 ANIMATION EVENT (END FRAME)
    public void EndAttack()
    {
        isAttacking = false;
        
        // Only reset block if not still holding the button
        if (!Input.GetMouseButton(1))
            isBlocking = false; 

        if (Time.time - lastAttackTime > comboResetTime)
            comboIndex = 0;
    }

    // ---------------- PLAYER DAMAGE + BLOCK ----------------

    public void TakeDamage(int damage)
    {
        if (isDead) return;

        // 🛡️ BLOCK NEGATES DAMAGE
        if (isBlocking)
        {
            animator.SetTrigger("Block"); // Play block impact
            return; // ❌ no damage
        }

        if (GameSession.Instance.mode == GameMode.SinglePlayer)
        {
            ApplyDamage(damage);
        }
        else
        {
            // Multiplayer: Intent only, actual damage applied via NetworkApplyDamage (stub)
            Debug.Log("[Multiplayer] Player health change requested but not applied locally.");
        }
    }

    // 🌐 Entry point for multiplayer damage confirmation or singleplayer application
    public void ApplyDamage(int damage)
    {
        currentHealth -= damage;
        animator.SetTrigger("Hurt");
        lastDamageTime = Time.time; // [NEW] Reset regen timer

        // [NEW] UI Update
        if (PlayerHealthUI.Instance != null)
            PlayerHealthUI.Instance.UpdateHealth(currentHealth, maxHealth);

        if (currentHealth <= 0)
            Die();
    }

    void Die()
    {
        if (isDead) return;
        isDead = true;

        lastDamageTime = 0; // Stop regen on death

        animator.SetBool("IsDead", true); // [NEW] Keep in death state
        animator.SetTrigger("Death");

        // Disable controls
        MonoBehaviour[] scripts = GetComponents<MonoBehaviour>();
        foreach (MonoBehaviour script in scripts)
        {
            if (script != this)
                script.enabled = false;
        }

        Rigidbody2D rb = GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.linearVelocity = Vector2.zero;
            rb.bodyType = RigidbodyType2D.Static;
        }

        // [NEW] Trigger auto-respawn IF lives remain
        if (currentRespawns > 0)
        {
            currentRespawns--;
            Debug.Log("Respawns remaining: " + currentRespawns);
            Invoke(nameof(Respawn), 1.5f);
        }
        else
        {
            Debug.Log("Game Over - No respawns left.");
            // Optional: SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    void Respawn()
    {
        isDead = false;
        currentHealth = maxHealth;

        // [NEW] UI Update
        if (PlayerHealthUI.Instance != null)
            PlayerHealthUI.Instance.UpdateHealth(currentHealth, maxHealth);

        // Reset Animator
        animator.SetBool("IsDead", false);
        animator.Rebind(); // [NEW] Reset all triggers and state
        animator.Update(0f);
        animator.Play("Idle");

        // Restore Physics & Position
        Rigidbody2D rb = GetComponent<Rigidbody2D>();
        Collider2D col = GetComponent<Collider2D>();

        if (rb != null)
        {
            rb.bodyType = RigidbodyType2D.Dynamic;
            rb.linearVelocity = Vector2.zero;
            
            // Move to last safe position BEFORE enabling scripts
            if (autoCheckpoint != null)
            {
                rb.position = autoCheckpoint.GetLastSafePosition();
                transform.position = autoCheckpoint.GetLastSafePosition();
            }
            rb.WakeUp();
        }

        if (col != null)
        {
            col.enabled = true; // [NEW] Ensure collider is on
        }

        // Re-enable scripts (Movement, etc.)
        MonoBehaviour[] scripts = GetComponents<MonoBehaviour>();
        foreach (MonoBehaviour script in scripts)
        {
            if (script != this)
                script.enabled = true;
        }
    }

    public void Heal(int amount)
    {
        if (isDead) return;
        currentHealth += amount;
        currentHealth = Mathf.Min(currentHealth, maxHealth);
        
        // [NEW] UI Update
        if (PlayerHealthUI.Instance != null)
            PlayerHealthUI.Instance.UpdateHealth(currentHealth, maxHealth);

        Debug.Log("Healed! Current HP: " + currentHealth);
    }

    void HandleRegeneration()
    {
        if (isDead || currentHealth >= maxHealth) return;

        // Wait for delay after last damage
        if (Time.time - lastDamageTime >= regenDelay)
        {
            regenAccumulator += regenRate * Time.deltaTime;

            if (regenAccumulator >= 1f)
            {
                int healAmount = Mathf.FloorToInt(regenAccumulator);
                currentHealth = Mathf.Min(currentHealth + healAmount, maxHealth);
                regenAccumulator -= healAmount;

                // [NEW] UI Update
                if (PlayerHealthUI.Instance != null)
                    PlayerHealthUI.Instance.UpdateHealth(currentHealth, maxHealth);
            }
        }
    }

    void PlaySound(AudioClip clip)
    {
        if (clip && audioSource)
            audioSource.PlayOneShot(clip);
    }

    void OnDrawGizmosSelected()
    {
        if (attackPoint == null) return;
        Gizmos.DrawWireSphere(attackPoint.position, attackRange);
    }
}
